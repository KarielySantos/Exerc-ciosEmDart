import 'dart:math';
import 'dart:io';
class Pessoa{
  String _nome = ''; 
  int _data_nasc = 0;
  double _altura = 0;
  int idade = 0;
  
  Pessoa(String nome, int data_nasc, double altura){
    this._nome = nome;
    this._data_nasc = data_nasc;
    this._altura = altura;
  }
  
  //getters
  int getDataNasc() => this._data_nasc;
  double getAltura() => this._altura;
  String getNome() => this._nome;
  
  //setters
  void setDataNasc(int data_nasc){
    this._data_nasc = data_nasc;
  }
  void setAltura(double altura){
    this._altura = altura;
  }
  void setNome(String nome){
    this._nome = nome;
  }
  
  //métodos
  void calcularIdade(){
    idade = 2022 - _data_nasc;
  }
  void imprimirDados(){
    print('--Dados--');
    print('Nome: $_nome');
    print('Idade: $idade anos');
    print('Altura: $_altura cm');
  }
}