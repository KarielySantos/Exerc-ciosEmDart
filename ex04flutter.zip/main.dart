import 'Pessoa.dart';
void main() {
  Pessoa pessoa1 = Pessoa('Kariely', 2004, 1.62);
  pessoa1.calcularIdade();
	pessoa1.imprimirDados();
}
